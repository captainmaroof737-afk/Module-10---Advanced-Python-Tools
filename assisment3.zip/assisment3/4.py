import random
import numpy as np
import matplotlib.pyplot as plt

values = [1, 2, 3]
probabilities = [0.25, 0.35, 0.4]

sample = np.random.choice(values, size=1000, p=probabilities)

mean = np.mean(sample)
variance = np.var(sample)
std_dev = np.std(sample)

print("Empirical Mean:", mean)
print("Empirical Variance:", variance)
print("Empirical Standard Deviation:", std_dev)
