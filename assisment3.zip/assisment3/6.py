import random
import numpy as np
import matplotlib.pyplot as plt

uniform_data = np.random.uniform(0, 1, 10000)

sample_means = []
for _ in range(1000):
    sample = np.random.choice(uniform_data, size=30)
    sample_means.append(np.mean(sample))

plt.hist(uniform_data, bins=30)
plt.title("Uniform Distribution")
plt.show()

plt.hist(sample_means, bins=30)
plt.title("Distribution of Sample Means (CLT)")
plt.show()
