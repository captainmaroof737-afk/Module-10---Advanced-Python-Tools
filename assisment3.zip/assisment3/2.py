import random
import numpy as np
import matplotlib.pyplot as plt


def probability_at_least_one_six(trials=10000):
    success = 0

    for _ in range(trials):
        rolls = [random.randint(1, 6) for _ in range(10)]
        if 6 in rolls:
            success += 1

    return success / trials

print("Probability of at least one 6 in 10 rolls:",
      probability_at_least_one_six())
