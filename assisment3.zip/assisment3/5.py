import random
import numpy as np
import matplotlib.pyplot as plt

exp_samples = np.random.exponential(scale=5, size=2000)

plt.hist(exp_samples, bins=30, density=True)
plt.title("Exponential Distribution Histogram")
plt.xlabel("Value")
plt.ylabel("Density")

x = np.linspace(0, max(exp_samples), 100)
pdf = (1/5) * np.exp(-x/5)
plt.plot(x, pdf)

plt.show()
