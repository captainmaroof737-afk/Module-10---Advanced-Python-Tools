import random
import numpy as np
import matplotlib.pyplot as plt

colors = ['Red'] * 5 + ['Green'] * 7 + ['Blue'] * 8
previous = None

count_prev_blue = 0
count_red_given_blue = 0

for _ in range(1000):
    current = random.choice(colors)

    if previous == 'Blue':
        count_prev_blue += 1
        if current == 'Red':
            count_red_given_blue += 1

    previous = current

prob_red_given_blue = count_red_given_blue / count_prev_blue
print("P(Red | Previous Blue):", prob_red_given_blue)
