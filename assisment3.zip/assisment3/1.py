import random
import numpy as np
import matplotlib.pyplot as plt


heads = 0
tails = 0
trials = 10000

for _ in range(trials):
    if random.choice(['H', 'T']) == 'H':
        heads += 1
    else:
        tails += 1

print("Experimental Probability of Heads:", heads / trials)
print("Experimental Probability of Tails:", tails / trials)
