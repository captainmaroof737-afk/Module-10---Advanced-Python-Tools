import random
import numpy as np
import matplotlib.pyplot as plt



sum_seven = 0
total_rolls = 10000

for _ in range(total_rolls):
    die1 = random.randint(1, 6)
    die2 = random.randint(1, 6)
    if die1 + die2 == 7:
        sum_seven += 1

print("Probability of getting sum 7:", sum_seven / total_rolls)
